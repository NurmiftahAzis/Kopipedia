// Checkout page functionality
window.addEventListener('DOMContentLoaded', () => {
  // Check if user is logged in
  const currentUser = JSON.parse(localStorage.getItem('currentUser'));
  if (!currentUser) {
    // Redirect to login page if not logged in
    window.location.href = 'login.html';
    return;
  }
  
  // Load cart items
  loadCartItems();
  
  // Load user addresses
  loadShippingAddresses(currentUser);
  
  // Handle payment form submission
  document.getElementById('payment-form').addEventListener('submit', handlePlaceOrder);
});

// Load cart items from localStorage
function loadCartItems() {
  const checkoutItems = document.getElementById('checkout-items');
  const checkoutTotal = document.getElementById('checkout-total');
  
  // Get cart items from localStorage
  const cartItems = JSON.parse(localStorage.getItem('shopping-cart')) || [];
  
  // Clear checkout items container
  checkoutItems.innerHTML = '';
  
  // Check if cart is empty
  if (cartItems.length === 0) {
    checkoutItems.innerHTML = '<p class="empty-message">Tidak ada produk dalam keranjang</p>';
    checkoutTotal.textContent = '0';
    
    // Disable place order button
    document.getElementById('place-order-btn').disabled = true;
    return;
  }
  
  // Enable place order button
  document.getElementById('place-order-btn').disabled = false;
  
  // Display cart items
  cartItems.forEach(item => {
    const itemElement = document.createElement('div');
    itemElement.className = 'checkout-item';
    itemElement.innerHTML = `
      <div class="item-info">
        <img src="${item.image}" alt="${item.name}" class="item-image">
        <div class="item-details">
          <h4>${item.name}</h4>
          <span class="item-price">${item.price}</span>
        </div>
      </div>
    `;
    
    checkoutItems.appendChild(itemElement);
  });
  
  // Calculate and display total
  const total = cartItems.reduce((sum, item) => sum + item.price, 0);
  checkoutTotal.textContent = total;
}

// Load user shipping addresses
function loadShippingAddresses(user) {
  const addressSelector = document.getElementById('shipping-address-selector');
  
  // Clear address selector
  addressSelector.innerHTML = '';
  
  // Check if user has addresses
  if (!user.addresses || user.addresses.length === 0) {
    addressSelector.innerHTML = `
      <p class="empty-message">Tidak ada alamat tersimpan</p>
      <a href="profile.html" class="button">Tambah Alamat Baru</a>
    `;
    return;
  }
  
  // Create address selection form
  const addressForm = document.createElement('form');
  addressForm.className = 'address-form';
  
  // Add addresses as radio options
  user.addresses.forEach(address => {
    const addressOption = document.createElement('div');
    addressOption.className = 'address-option';
    addressOption.innerHTML = `
      <input type="radio" id="address-${address.id}" name="shipping-address" value="${address.id}" ${user.addresses[0].id === address.id ? 'checked' : ''}>
      <label for="address-${address.id}">
        <div class="address-option-content">
          <h4>${address.label}</h4>
          <p><strong>${address.recipientName}</strong> (${address.recipientPhone})</p>
          <p>${address.addressDetail}</p>
          <p>Kode Pos: ${address.postalCode}</p>
        </div>
      </label>
    `;
    
    addressForm.appendChild(addressOption);
  });
  
  // Add link to add new address
  const addAddressLink = document.createElement('a');
  addAddressLink.href = 'profile.html';
  addAddressLink.className = 'button';
  addAddressLink.style.marginTop = '1rem';
  addAddressLink.textContent = 'Tambah Alamat Baru';
  
  // Append to address selector
  addressSelector.appendChild(addressForm);
  addressSelector.appendChild(addAddressLink);
}

// Handle place order button click
function handlePlaceOrder(e) {
  e.preventDefault();
  
  // Get current user
  const currentUser = JSON.parse(localStorage.getItem('currentUser'));
  if (!currentUser) return;
  
  // Get cart items
  const cartItems = JSON.parse(localStorage.getItem('shopping-cart')) || [];
  if (cartItems.length === 0) {
    Swal.fire({
      icon: 'error',
      title: 'Keranjang Kosong',
      text: 'Tidak ada produk dalam keranjang.'
    });
    return;
  }
  
  // Get selected address
  const selectedAddressInput = document.querySelector('input[name="shipping-address"]:checked');
  if (!selectedAddressInput && currentUser.addresses && currentUser.addresses.length > 0) {
    Swal.fire({
      icon: 'error',
      title: 'Alamat Belum Dipilih',
      text: 'Silakan pilih alamat pengiriman.'
    });
    return;
  }
  
  // Get selected payment method
  const selectedPaymentMethod = document.querySelector('input[name="payment-method"]:checked').value;
  
  // Create order object
  const order = {
    id: Date.now().toString(),
    userId: currentUser.id,
    items: cartItems,
    total: cartItems.reduce((sum, item) => sum + item.price, 0),
    addressId: selectedAddressInput ? selectedAddressInput.value : null,
    paymentMethod: selectedPaymentMethod,
    status: 'pending',
    createdAt: new Date().toISOString()
  };
  
  // Get existing orders from localStorage
  const orders = JSON.parse(localStorage.getItem('orders')) || [];
  
  // Add new order
  orders.push(order);
  
  // Save to localStorage
  localStorage.setItem('orders', JSON.stringify(orders));
  
  // Clear shopping cart
  localStorage.removeItem('shopping-cart');
  
  // Show success message
  Swal.fire({
    icon: 'success',
    title: 'Pesanan Berhasil Dibuat',
    text: 'Terima kasih telah berbelanja di KopiPedia!',
    timer: 2000,
    showConfirmButton: false
  }).then(() => {
    // Redirect to home page
    window.location.href = 'index.html';
  });
}