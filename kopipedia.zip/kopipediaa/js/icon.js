window.addEventListener('DOMContentLoaded', () => {
  
  // feather icon 
  feather.replace();
  
});