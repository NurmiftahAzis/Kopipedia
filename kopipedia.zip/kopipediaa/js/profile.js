// Profile page functionality
window.addEventListener('DOMContentLoaded', () => {
  // Check if user is logged in
  const currentUser = JSON.parse(localStorage.getItem('currentUser'));
  if (!currentUser) {
    // Redirect to login page if not logged in
    window.location.href = 'login.html';
    return;
  }
  
  // Load user profile information
  loadProfileInfo(currentUser);
  
  // Load user addresses
  loadAddresses(currentUser);
  
  // Initialize address form modal
  initAddressModal();
});

// Load user profile information
function loadProfileInfo(user) {
  document.getElementById('profile-name').textContent = user.fullname;
  document.getElementById('profile-email').textContent = user.email;
  document.getElementById('profile-phone').textContent = user.phone;
  
  // Format date
  const createdDate = new Date(user.createdAt);
  const formattedDate = createdDate.toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });
  document.getElementById('profile-date').textContent = formattedDate;
}

// Load user addresses
function loadAddresses(user) {
  const addressList = document.getElementById('address-list');
  
  // Clear address list
  addressList.innerHTML = '';
  
  // Check if user has addresses
  if (!user.addresses || user.addresses.length === 0) {
    addressList.innerHTML = '<p class="empty-message">Belum ada alamat tersimpan</p>';
    return;
  }
  
  // Display addresses
  user.addresses.forEach(address => {
    const addressCard = document.createElement('div');
    addressCard.className = 'address-card';
    addressCard.innerHTML = `
      <div class="address-header">
        <h4>${address.label}</h4>
        <div class="address-actions">
          <button class="btn-edit" data-id="${address.id}"><i data-feather="edit"></i></button>
          <button class="btn-delete" data-id="${address.id}"><i data-feather="trash"></i></button>
        </div>
      </div>
      <div class="address-details">
        <p><strong>${address.recipientName}</strong> (${address.recipientPhone})</p>
        <p>${address.addressDetail}</p>
        <p>Kode Pos: ${address.postalCode}</p>
      </div>
    `;
    
    addressList.appendChild(addressCard);
  });
  
  // Initialize Feather icons
  feather.replace();
  
  // Add event listeners for edit and delete buttons
  document.querySelectorAll('.btn-edit').forEach(btn => {
    btn.addEventListener('click', () => editAddress(btn.dataset.id));
  });
  
  document.querySelectorAll('.btn-delete').forEach(btn => {
    btn.addEventListener('click', () => deleteAddress(btn.dataset.id));
  });
}

// Initialize address form modal
function initAddressModal() {
  const addAddressBtn = document.getElementById('add-address-btn');
  const addressModal = document.querySelector('.modal[data-id="addressModal"]');
  const addressForm = document.getElementById('address-form');
  const closeBtn = addressModal.querySelector('.btn-modal-close');
  
  // Show modal when add address button is clicked
  addAddressBtn.addEventListener('click', () => {
    // Reset form
    addressForm.reset();
    document.getElementById('address-id').value = '';
    
    // Show modal
    addressModal.classList.add('active');
  });
  
  // Hide modal when close button is clicked
  closeBtn.addEventListener('click', () => {
    addressModal.classList.remove('active');
  });
  
  // Handle form submission
  addressForm.addEventListener('submit', handleAddressFormSubmit);
}

// Handle address form submission
function handleAddressFormSubmit(e) {
  e.preventDefault();
  
  // Get form values
  const addressId = document.getElementById('address-id').value;
  const label = document.getElementById('address-label').value;
  const recipientName = document.getElementById('recipient-name').value;
  const recipientPhone = document.getElementById('recipient-phone').value;
  const addressDetail = document.getElementById('address-detail').value;
  const postalCode = document.getElementById('postal-code').value;
  
  // Get current user
  const currentUser = JSON.parse(localStorage.getItem('currentUser'));
  if (!currentUser) return;
  
  // Get all users
  const users = JSON.parse(localStorage.getItem('users')) || [];
  
  // Find current user in users array
  const userIndex = users.findIndex(user => user.id === currentUser.id);
  if (userIndex === -1) return;
  
  // Initialize addresses array if it doesn't exist
  if (!currentUser.addresses) {
    currentUser.addresses = [];
    users[userIndex].addresses = [];
  }
  
  // Create new address object
  const newAddress = {
    id: addressId || Date.now().toString(),
    label,
    recipientName,
    recipientPhone,
    addressDetail,
    postalCode
  };
  
  // Check if editing existing address or adding new one
  if (addressId) {
    // Update existing address
    const addressIndex = currentUser.addresses.findIndex(addr => addr.id === addressId);
    if (addressIndex !== -1) {
      currentUser.addresses[addressIndex] = newAddress;
      users[userIndex].addresses[addressIndex] = newAddress;
    }
  } else {
    // Add new address
    currentUser.addresses.push(newAddress);
    users[userIndex].addresses.push(newAddress);
  }
  
  // Update localStorage
  localStorage.setItem('currentUser', JSON.stringify(currentUser));
  localStorage.setItem('users', JSON.stringify(users));
  
  // Hide modal
  document.querySelector('.modal[data-id="addressModal"]').classList.remove('active');
  
  // Reload addresses
  loadAddresses(currentUser);
  
  // Show success message
  Swal.fire({
    icon: 'success',
    title: addressId ? 'Alamat Diperbarui' : 'Alamat Ditambahkan',
    text: addressId ? 'Alamat berhasil diperbarui.' : 'Alamat baru berhasil ditambahkan.',
    timer: 2000,
    showConfirmButton: false
  });
}

// Edit address
function editAddress(addressId) {
  // Get current user
  const currentUser = JSON.parse(localStorage.getItem('currentUser'));
  if (!currentUser || !currentUser.addresses) return;
  
  // Find address by id
  const address = currentUser.addresses.find(addr => addr.id === addressId);
  if (!address) return;
  
  // Fill form with address data
  document.getElementById('address-id').value = address.id;
  document.getElementById('address-label').value = address.label;
  document.getElementById('recipient-name').value = address.recipientName;
  document.getElementById('recipient-phone').value = address.recipientPhone;
  document.getElementById('address-detail').value = address.addressDetail;
  document.getElementById('postal-code').value = address.postalCode;
  
  // Show modal
  document.querySelector('.modal[data-id="addressModal"]').classList.add('active');
}

// Delete address
function deleteAddress(addressId) {
  // Confirm deletion
  Swal.fire({
    icon: 'warning',
    title: 'Hapus Alamat',
    text: 'Apakah Anda yakin ingin menghapus alamat ini?',
    showCancelButton: true,
    confirmButtonText: 'Ya, Hapus',
    cancelButtonText: 'Batal'
  }).then((result) => {
    if (result.isConfirmed) {
      // Get current user
      const currentUser = JSON.parse(localStorage.getItem('currentUser'));
      if (!currentUser || !currentUser.addresses) return;
      
      // Get all users
      const users = JSON.parse(localStorage.getItem('users')) || [];
      
      // Find current user in users array
      const userIndex = users.findIndex(user => user.id === currentUser.id);
      if (userIndex === -1) return;
      
      // Remove address from arrays
      currentUser.addresses = currentUser.addresses.filter(addr => addr.id !== addressId);
      users[userIndex].addresses = users[userIndex].addresses.filter(addr => addr.id !== addressId);
      
      // Update localStorage
      localStorage.setItem('currentUser', JSON.stringify(currentUser));
      localStorage.setItem('users', JSON.stringify(users));
      
      // Reload addresses
      loadAddresses(currentUser);
      
      // Show success message
      Swal.fire({
        icon: 'success',
        title: 'Alamat Dihapus',
        text: 'Alamat berhasil dihapus.',
        timer: 2000,
        showConfirmButton: false
      });
    }
  });
}