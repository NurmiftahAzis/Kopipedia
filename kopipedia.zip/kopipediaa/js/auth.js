// Authentication functionality
window.addEventListener('DOMContentLoaded', () => {
  // Initialize navbar functionality
  initNavbar();
  
  // Check if user is logged in
  checkAuthStatus();
  
  // Handle login form submission
  const loginForm = document.getElementById('login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', handleLogin);
  }
  
  // Handle registration form submission
  const registerForm = document.getElementById('register-form');
  if (registerForm) {
    registerForm.addEventListener('submit', handleRegistration);
  }
});

// Initialize navbar functionality
function initNavbar() {
  // Hamburger menu functionality
  const navbarListGroup = document.querySelector('.navbar-list-group');
  const navbarButton = document.querySelector('#hamburger');
  if (navbarButton) {
    navbarButton.addEventListener('click', () => {
      navbarListGroup.classList.toggle('active');
    });
  }
  
  document.addEventListener('click', event => {
    const navbar = document.querySelector('.navbar');
    if (navbarButton && !navbarButton.contains(event.target) && !navbar.contains(event.target)) {
      navbarListGroup.classList.remove('active');
    }
  });
}

// Check if user is logged in
function checkAuthStatus() {
  const currentUser = JSON.parse(localStorage.getItem('currentUser'));
  if (currentUser) {
    // Update UI for logged-in user
    updateAuthUI(true);
  } else {
    // Update UI for logged-out user
    updateAuthUI(false);
  }
}

// Update UI based on authentication status
function updateAuthUI(isLoggedIn) {
  const navbarIcon = document.querySelector('.navbar-icon');
  if (!navbarIcon) return;
  
  if (isLoggedIn) {
    // Get current user
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    
    // Clear existing auth buttons
    const authButtons = navbarIcon.querySelectorAll('.button');
    authButtons.forEach(button => button.remove());
    
    // Add profile link and logout button
    const profileLink = document.createElement('a');
    profileLink.href = 'profile.html';
    profileLink.className = 'button';
    profileLink.style.marginRight = '1rem';
    profileLink.textContent = currentUser.fullname.split(' ')[0] || 'Profil';
    
    const logoutButton = document.createElement('a');
    logoutButton.href = '#';
    logoutButton.className = 'button';
    logoutButton.style.marginRight = '1rem';
    logoutButton.textContent = 'Keluar';
    logoutButton.addEventListener('click', (e) => {
      e.preventDefault();
      handleLogout();
    });
    
    // Insert before hamburger menu
    const hamburger = navbarIcon.querySelector('#hamburger');
    navbarIcon.insertBefore(profileLink, hamburger);
    navbarIcon.insertBefore(logoutButton, hamburger);
  }
}

// Handle login form submission
function handleLogin(e) {
  e.preventDefault();
  
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  
  // Get users from localStorage
  const users = JSON.parse(localStorage.getItem('users')) || [];
  
  // Find user with matching email and password
  const user = users.find(u => u.email === email && u.password === password);
  
  if (user) {
    // Store current user in localStorage
    localStorage.setItem('currentUser', JSON.stringify(user));
    
    // Show success message
    Swal.fire({
      icon: 'success',
      title: 'Login Berhasil',
      text: 'Anda akan dialihkan ke halaman utama.',
      timer: 2000,
      showConfirmButton: false
    }).then(() => {
      // Redirect to home page
      window.location.href = 'index.html';
    });
  } else {
    // Show error message
    Swal.fire({
      icon: 'error',
      title: 'Login Gagal',
      text: 'Email atau password salah. Silakan coba lagi.'
    });
  }
}

// Handle registration form submission
function handleRegistration(e) {
  e.preventDefault();
  
  const fullname = document.getElementById('fullname').value;
  const email = document.getElementById('email').value;
  const phone = document.getElementById('phone').value;
  const password = document.getElementById('password').value;
  const confirmPassword = document.getElementById('confirm-password').value;
  
  // Validate password match
  if (password !== confirmPassword) {
    Swal.fire({
      icon: 'error',
      title: 'Registrasi Gagal',
      text: 'Password dan konfirmasi password tidak cocok.'
    });
    return;
  }
  
  // Get existing users from localStorage
  const users = JSON.parse(localStorage.getItem('users')) || [];
  
  // Check if email already exists
  if (users.some(user => user.email === email)) {
    Swal.fire({
      icon: 'error',
      title: 'Registrasi Gagal',
      text: 'Email sudah terdaftar. Silakan gunakan email lain.'
    });
    return;
  }
  
  // Create new user object
  const newUser = {
    id: Date.now().toString(),
    fullname,
    email,
    phone,
    password,
    addresses: [],
    createdAt: new Date().toISOString()
  };
  
  // Add new user to users array
  users.push(newUser);
  
  // Save updated users array to localStorage
  localStorage.setItem('users', JSON.stringify(users));
  
  // Show success message
  Swal.fire({
    icon: 'success',
    title: 'Registrasi Berhasil',
    text: 'Silakan login dengan akun baru Anda.',
    timer: 2000,
    showConfirmButton: false
  }).then(() => {
    // Redirect to login page
    window.location.href = 'login.html';
  });
}

// Handle logout
function handleLogout() {
  // Remove current user from localStorage
  localStorage.removeItem('currentUser');
  
  // Show success message
  Swal.fire({
    icon: 'success',
    title: 'Logout Berhasil',
    text: 'Anda telah keluar dari akun.',
    timer: 2000,
    showConfirmButton: false
  }).then(() => {
    // Redirect to home page
    window.location.href = 'index.html';
  });
}